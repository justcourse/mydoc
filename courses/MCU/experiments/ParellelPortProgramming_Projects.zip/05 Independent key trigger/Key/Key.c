#include <reg52.h>
#define uchar unsigned char
#define uint unsigned int
sbit LED1 = P0^0; 
sbit LED2 = P0^1;

sbit K1 = P1^0;
sbit K2 = P1^1;

void DelayMS(uint x)
{
 	uchar t;
	while(x--)
	{
	 	for(t=120;t>0;t--);
	}
}

void main()
{
 	P0=0xff;
	P1=0xff;
	while(1)
	{
	 	LED1 = K1;
		LED2 = K2;
		DelayMS(10);
	}
}
